document.getElementById("mathSolverForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const problemInput = document.getElementById("problemInput").value;
    const fileInput = document.getElementById("fileInput").files[0];
    const solutionOutput = document.getElementById("solutionOutput");

    solutionOutput.textContent = "Processing...";

    if (problemInput.trim()) {
        const solution = await solveMathProblem(problemInput);
        solutionOutput.textContent = solution;
    } else if (fileInput) {
        const textFromImage = await extractTextFromImage(fileInput);
        const solution = await solveMathProblem(textFromImage);
        solutionOutput.textContent = solution;
    } else {
        solutionOutput.textContent = "Please enter a problem or upload a file.";
    }
});

async function solveMathProblem(problem) {
    try {
        const response = await fetch("http://127.0.0.1:5000/solve", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ problem }),
        });
        const data = await response.json();
        return data.solution || "Could not solve the problem.";
    } catch (error) {
        return "Error solving the problem: " + error.message;
    }
}

async function extractTextFromImage(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = async (event) => {
            const image = event.target.result;
            const { data: { text } } = await Tesseract.recognize(image, "eng");
            resolve(text);
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });
}