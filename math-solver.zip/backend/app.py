from flask import Flask, request, jsonify
from sympy import sympify, solve

app = Flask(__name__)

@app.route("/solve", methods=["POST"])
def solve_problem():
    data = request.json
    problem = data.get("problem", "")
    try:
        expr = sympify(problem)
        solution = solve(expr)
        return jsonify({"solution": str(solution)})
    except Exception as e:
        return jsonify({"solution": f"Error: {str(e)}"})

if __name__ == "__main__":
    app.run(debug=True)