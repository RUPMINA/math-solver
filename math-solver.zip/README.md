# Global Math Solver

A web application to solve mathematical problems using text input or file uploads.

## Features
- Enter math problems as text.
- Upload images or files containing math problems.
- Provides step-by-step solutions.

## Installation and Usage

### Frontend
1. Navigate to the `frontend` folder.
2. Start a local server:
   ```bash
   python -m http.server 8000
   ```
3. Open `http://localhost:8000` in your browser.

### Backend
1. Navigate to the `backend` folder.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the Flask server:
   ```bash
   python app.py
   ```
4. The server will run at `http://127.0.0.1:5000`.

## Deployment
- Host the frontend on platforms like Netlify or Vercel.
- Host the backend on Heroku, AWS, or any cloud provider.